chrome.runtime.sendMessage({}, function (response) {
	var readyStateCheckInterval = setInterval(function () {
		if (document.readyState === "complete") {
			clearInterval(readyStateCheckInterval);

			// ----------------------------------------------------------
			// This part of the script triggers when page is done loading
			console.log("Hello. This message was sent from scripts/inject.js");
			// ----------------------------------------------------------
			//setInterval(clickConnect, 300000);	//4 minute
			setInterval(clickAlive, 300000);	//4 minute
			//setInterval(clickAliveFiles, 300000);	//5 minute
		}
	}, 10);
});


// Credit to https://medium.com/@shivamrawat_756/how-to-prevent-google-colab-from-disconnecting-717b88a128c0
function clickConnect() {
	try {
		 document.querySelector("#top-toolbar > colab-connect-button").shadowRoot.querySelector("#connect").click();
		// this also works, if above one doesn't work, comment it and uncomment below one
		//document.querySelector("colab-connect-button").shadowRoot.getElementById('connect').click();
		setTimeout(clickDismiss, 500);
		console.log("Keeping Colab Alive!");	
	} catch (error) {
		console.log(error);
	}
}


function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function clickDismiss() {
	
	try {	
		
		// click manage session button
		document.querySelector("colab-usage-display").shadowRoot.querySelector("paper-button").click();
	
		} catch (error) {
		console.log(error);
	}
	
		try {
			// leave from manage session window
			await sleep(1000);
			document.querySelector('colab-sessions-dialog').shadowRoot.querySelector('.dismiss').click();
				} catch (error) {
		console.log(error);
	}
	
		try {	
			// click close button
			await sleep(1000);
			document.querySelector("paper-tab").querySelector("paper-icon-button").shadowRoot.getElementById('icon').click();
				} catch (error) {
		console.log(error);
	}
	
}

function clickAlive() {
	try {
		 document.querySelector("#cell-6bkIZt2oYnnQ > .main-content > .codecell-input-output > .form.layout.horizontal.inputarea > .cell-gutter > .cell-execution-container > colab-run-button").click();
		console.log("Keeping Colab Alive!");	
	} catch (error) {
		console.log(error);
	}
}

function clickAliveFiles() {
	try {
		 document.querySelector("div.notebook-vertical.large-notebook:nth-child(10) > div.notebook-horizontal:nth-child(2) > colab-left-pane:nth-child(1) > div.colab-left-pane-nib.layout.vertical > div.left-pane-top:nth-child(1) > div.left-pane-button:nth-child(4)").querySelector("paper-icon-button").shadowRoot.getElementById('icon').click();
		 sleep(3000);
		 document.querySelector("div.notebook-vertical.large-notebook.colab-left-pane-open > div.notebook-horizontal > colab-left-pane > colab-resizer > div.resizer-contents > div.colab-left-pane-header.layout.horizontal.noshrink").querySelector("paper-icon-button").shadowRoot.getElementById('icon').click();
		console.log("Keeping Colab Alive Files!");	
	} catch (error) {
		console.log(error);
	}
}
